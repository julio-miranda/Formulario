//hecho: Julio Miranda
//carnet:MR18031
#include<FL/Fl.H>
#include<FL/Fl_Window.H>
#include<FL/Fl_Box.H>
#include<FL/Fl_Button.H>
#include<FL/Fl_Input.H>
#include<FL/fl_message.H>

using namespace std;

class Ventana : public Fl_Window{
Fl_Window *window;
Fl_Box *box;
Fl_Button *boton1;
Fl_Button *boton2;
Fl_Button *boton3;
Fl_Input1 *input1;
Fl_Input2 *input2;
Fl_Input3 *input3;
Fl_Input4 *input4;

public:
Ventana():Fl_Window(350,180){
 	begin();
	box = new Fl_Box(20,40,260,100,"Bienvenido/a");
	box->box(FL_RFLAT_BOX);
    box->labelsize(36);
	box->labelfont(FL_BOLD+FL_ITALIC);
	box->labeltype(FL_SHADOW_LABEL);
	
    boton1 = new Fl_Button(20, 120, 120, 45, "Tipos de Pizzas: ");
    boton1->type(FL_NORMAL_BUTTON);
    boton1->color(FL_GREEN);
	boton2 = new Fl_Button(20, 40, 120, 45, "Ordenar: ");
    boton2->type(FL_NORMAL_BUTTON);
	boton2->color(FL_WHILE);
	boton3 = new Fl_Button(20, 120, 120, 45, "Cancelar: ");
    boton3->type(FL_NORMAL_BUTTON);
    boton3->color(FL_BLUE);
	
    input1 = new Fl_Input(156, 120, 80, 45, " Nombre: ");
	input1->value("***********");
    input2 = new Fl_Input(156, 120, 80, 45, " Iniciales: ");
	input2->value("**********");
    input3 = new Fl_Input(156, 120, 80, 45, " Edad: ");
	input3->value("#######");
	input4 = new Fl_Input(156, 120, 80, 45, " Pizza: ");
	input4->value("**********************");
	
	
	end();
    boton1->callback(Tipos_de_Pizzas_CB,(void*)this);
	boton2->callback(Guardar_CB,(void*)this);
	boton3->callback(Cancelar_CB,(void*)this);
}
static void Tipos_de_Pizzas_CB(Fl_Widget *w,void *data){

if(strcmp(w->label(),"Tipos de Pizzas: ")==0){
 fl_message("%s","Pizza Hawaina=$4.99.");
 fl_message("%s","Pizza de Jamon=$5.00.");
 fl_message("%s","Pizza de Peperoni=$4.50.");
 fl_message("%s","Pizza Vegetariana=$5.00.");
}
}

 static void Guardar_CB(Fl_Widget *w, void *data) {
       Ventana *e = (Ventana*)data;
	if (e->Guardar("Orden.txt") == 0)
	{
   	 fl_message("%s: %s", "Orden guardada");
	}
   
 }


   static void Cancelar_CB(Fl_Widget *w, void *data) {

      Ventana *e = (Ventana*)data;
      e->hide();                      
       //limpiar
      // input->value("");
   }


void  SetT1(const char *val){    
    input1->value(val);
}
const char *GetT1() const 
{ 
return input1->value();   
}

void  SetT2(const char *val){    
    input2->value(val);
}
const char *GetT2() const 
{ 
return input2->value();   
}

void  SetT3(const char *val){    
    input3->value(val);
}

const char *GetT3() const 
{ 
return input3->value();   
}

void  SetT4(const char *val){    
    input4->value(val);
}
const char *GetT4() const 
{ 
return input4->value();   
}

int Guardar(const char *Ordencp){
	
        FILE *fp = fopen(Ordencp, "O");
        if ( !fp ) {
            fl_message("%s: %s", Ordencp, strerror(errno));
            return -1;
        }
        fprintf(fp, "Nombre: %s\n", input1->value());
        fprintf(fp, "Iniciales: %s\n", input2->value());
        fprintf(fp, "Edad: %s\n", input3->value());
        fprintf(fp, "Pizza: %s\n", input4->value());
        
        fclose(fp);
        return 0;
    }


};


int main() {
Ventana *e=new Ventana();
e->show();
return Fl::run();
}

